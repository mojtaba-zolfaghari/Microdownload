﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Microdownload.DataLayer.Migrations
{
    public partial class V2019_05_04_2102 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
 migrationBuilder.AddColumn<string>(
                name: "Description",
                table: "Institutes",
                nullable: true);

            //migrationBuilder.DropColumn(
            //    name: "Description",
            //    table: "Institutes");

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
           
        }
    }
}
