﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Microdownload.DataLayer.Migrations
{
    public partial class V2019_05_03_2007 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
