﻿namespace Microdownload.Services.Identity
{
    public static class ConstantRoles
    {
        public const string Admin = nameof(Admin);
    }
}