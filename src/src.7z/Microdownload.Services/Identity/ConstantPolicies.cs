﻿namespace Microdownload.Services.Identity
{
    public static class ConstantPolicies
    {
        public const string DynamicPermission = nameof(DynamicPermission);
        public const string DynamicPermissionClaimType = nameof(DynamicPermission);
    }
}