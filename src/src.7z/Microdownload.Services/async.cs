﻿namespace Microdownload.Services
{
    public class async<T>
    {
    }
}