﻿namespace Microdownload.ViewModels.Identity
{
    public static class ViewModelConstants
    {
        public const string AntiForgeryToken = "__RequestVerificationToken";
    }
}