﻿namespace Microdownload.ViewModels.Identity
{
    public class ModelIdViewModel
    {
        public string Id { set; get; }
        public int SumWageId { set; get; }
        public int InsuranceType { set; get; }
        public int CourseStatus { set; get; }
    }
}