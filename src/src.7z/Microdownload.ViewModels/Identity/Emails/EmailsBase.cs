﻿namespace Microdownload.ViewModels.Identity.Emails
{
    public abstract class EmailsBase
    {
        public string EmailSignature { set; get; }
        public string MessageDateTime { set; get; }
    }
}