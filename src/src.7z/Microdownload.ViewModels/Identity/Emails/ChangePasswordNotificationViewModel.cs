﻿using Microdownload.Entities.Identity;

namespace Microdownload.ViewModels.Identity.Emails
{
    public class ChangePasswordNotificationViewModel : EmailsBase
    {
        public User User { set; get; }
    }
}