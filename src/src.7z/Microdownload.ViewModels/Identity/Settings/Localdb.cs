﻿namespace Microdownload.ViewModels.Identity.Settings
{
    public class Localdb
    {
        public string InitialCatalog { get; set; }
        public string AttachDbFilename { get; set; }
    }
}