﻿namespace Microdownload.ViewModels.Identity.Settings
{
    public enum ActiveDatabase
    {
        LocalDb,
        SqlServer,
        InMemoryDatabase
    }
}