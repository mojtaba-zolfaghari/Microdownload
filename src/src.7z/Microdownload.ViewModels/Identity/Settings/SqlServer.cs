﻿namespace Microdownload.ViewModels.Identity.Settings
{
    public class SqlServer
    {
        public string ApplicationDbContextConnection { get; set; }
    }
}