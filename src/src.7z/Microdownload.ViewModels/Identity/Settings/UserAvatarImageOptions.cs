namespace Microdownload.ViewModels.Identity.Settings
{
    public class UserAvatarImageOptions
    {
        public int MaxWidth { set; get; }
        public int MaxHeight { set; get; }
    }
}