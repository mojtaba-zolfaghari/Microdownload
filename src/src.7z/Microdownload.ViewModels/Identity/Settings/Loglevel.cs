namespace Microdownload.ViewModels.Identity.Settings
{
    public class Loglevel
    {
        public string Default { get; set; }
        public string System { get; set; }
        public string Microsoft { get; set; }
    }
}