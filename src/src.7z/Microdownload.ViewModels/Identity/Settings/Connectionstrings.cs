﻿namespace Microdownload.ViewModels.Identity.Settings
{
    public class Connectionstrings
    {
        public SqlServer SqlServer { get; set; }
        public Localdb LocalDb { get; set; }
    }
}