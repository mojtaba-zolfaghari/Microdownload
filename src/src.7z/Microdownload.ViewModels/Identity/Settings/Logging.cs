﻿namespace Microdownload.ViewModels.Identity.Settings
{
    public class Logging
    {
        public bool IncludeScopes { get; set; }
        public Loglevel LogLevel { get; set; }
    }
}