﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Microdownload.ViewModels
{
    public class MelatNewsViewModel
    {
        public string Title { get; set; }

        public string ImgUrl { get; set; }

        public string Text { get; set; }

        public string Link { get; set; }

        public string Published { get; set; }



    }
}
