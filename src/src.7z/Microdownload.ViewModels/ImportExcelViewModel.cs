﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;

namespace Microdownload.ViewModels
{
    public class ImportExcelViewModel
    {

    }
}
